import React from 'react'
import './App.css';
import React, { useEffect/*, useState*/, Component } from "react";
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import { TextField, Button } from '@material-ui/core';
import axios from 'axios';
import 'fontsource-roboto';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Paper from '@material-ui/core/Paper';
import AppBar from '@material-ui/core/AppBar';
import IconButton from '@material-ui/core/IconButton';
import Snackbar from '@material-ui/core/Snackbar';
import SnackbarContent from '@material-ui/core/SnackbarContent';
import EventIcon from '@material-ui/icons/Event';
import CreateIcon from '@material-ui/icons/Create';
import ForwardIcon from '@material-ui/icons/Forward';
import HistoryIcon from '@material-ui/icons/History';
import SettingsIcon from '@material-ui/icons/Settings';
import CloseIcon from '@material-ui/icons/Close';
import InputIcon from '@material-ui/icons/Input';
import CheckIcon from '@material-ui/icons/Check';
import PostAddIcon from '@material-ui/icons/PostAdd';

function LoginComponent() {
    return (
        <div>
            
        </div>
    )
}

export default LoginComponent
