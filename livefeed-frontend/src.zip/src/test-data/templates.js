
const templates = [{
    template_id: 1,
    template_name: "Question Set 1"
},
{
    template_id: 2,
    template_name: "Question Set 2"
},
{
    template_id: 3,
    template_name: "Question Set 3"
}];

export default templates;

