const EventHistoryComponent = () => {
    return (
        <div>
            This page is not part of the prototype
        </div>
    )
}
export default EventHistoryComponent;