const AccountSettingComponent = () => {
    return (
        <div>
            This page is not part of the prototype
        </div>
    )
}
export default AccountSettingComponent;